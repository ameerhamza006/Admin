<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Terminology
    |--------------------------------------------------------------------------
    */

    'shop' => 'Shop',
    'shops' => 'Shops',

    'transporter' => 'Delivery Boy',
    'transporters' => 'Delivery Boys',

    'order' => 'Order',
    'orders' => 'Orders',

    'category' => 'Category',
    'categories' => 'Categories',

];
